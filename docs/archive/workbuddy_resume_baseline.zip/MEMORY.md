# QuantScore 长期约定

- 项目根目录：`LOCAL_PRIVATE_PATH github 项目。
- Stage2 真实网络失败必须如实标记 `NETWORK_FAILED`，不得使用 mock 或伪造行情替代。
- V1.4 固定 benchmark 为 `000001.SH` / 上证指数；评分语义继承 V1.3，`assumption_version=v1.3`。
- 执行测试使用 `<PYTHON_ROOT>/python.exe`、项目 `.deps` 和项目内 `.pytest-tmp` 临时目录。
