# 实际测试报告

## Stage 2 验收补充

Stage 2 离线测试保留原有测试，不删除原测试；覆盖 symbol（600519/000001/000001.SH）、固定 benchmark、raw/qfq schema 与日期对齐、缓存 hit/TTL/refresh、有限重试、OHLC/重复日期校验、weekly/monthly 完成周期、as_of/no-lookahead、API health/analyze/rules/data status、CLI JSON 以及缺基准/缺涨跌停的降级。D2、F1-X、F2、R3、R5 当前保留 NOT_IMPLEMENTED 与 UNKNOWN 守卫，不能把守卫测试称为业务实现通过。

真实网络结果单列于 `docs/STAGE2_DATA_SMOKE_REPORT.md` 和 `outputs/smoke/stage2_smoke_report.json`；600519、000001、000001.SH 本轮真实请求均因 ProxyError 为 `NETWORK_FAILED`，因此 Stage 2 总状态为 PARTIAL，不使用 mock 冒充 REAL DATA PASS。

敏感扫描：扫描 app/config/docs/tests/tools/outputs 共 103 个交付文件；未发现硬编码 token、cookie、API key、邮箱或手机号。命中的路径仅是需求/脚本中的本机路径文本，不是凭据；TUSHARE_TOKEN 仅通过环境变量读取。


- 最新总数：374
- PASS：373
- FAIL/ERROR：0
- SKIP：1（T20：自动选股排名明确排除于 Stage 2）
- 实际命令：`<PYTHON_ROOT>/python.exe -m pytest -q --tb=line --junitxml=outputs/runtime/qa-junit.xml`，并显式设置项目 `.deps` 与 `.pytest-tmp`。
- 结果：373 passed, 1 skipped, 1 warning；验证阶段包含 CLI 文本摘要修复后的完整回归。
- 环境：Python 3.11.0；依赖版本见requirements.txt；人工构造OHLCV；核心测试不联网。
- Stage 1原182项场景全部保留；端点/状态等预期按用户V1.2明文迁移，原件归档。
- Stage 1.1的241项测试保留；本轮预期变更仅来自用户V1.3确认；基线归档。
- 原始结果：outputs/pytest-results.xml；跳过不等于通过。

## 第11章最低验收

| ID | 状态 | 证据/原因 |
|---|---|---|
| T01 | PASS | test_T01_short_M60_history |
| T02 | PASS | test_pending_spec_acceptance[T02-C5\u5e73\u53f0\u591a\u6570\u65e5/\u5de5\u7a0b\u8fb9\u754c\u672a\u5b9a\uff0c\u672a\u5b9e\u73b0] |
| T03 | PASS | test_T03_n_intraday_break |
| T04 | PASS | test_T04_n_second_start |
| T05 | PASS | test_pending_spec_acceptance[T05-F1-T\u90e8\u5206T\u5f62\u51e0\u4f55\u672a\u5b9a\uff0c\u672a\u5b9e\u73b0] |
| T06 | PASS | test_T06_double_top_invalidated |
| T07 | PASS | test_T07_double_top_confirmed |
| T08 | PASS | test_pending_spec_acceptance[T08-C6/R8\u591a\u5468\u671f\u5b89\u5168\u5e26\u68c0\u6d4b\u672a\u5b9e\u73b0] |
| T09 | PASS | test_pending_spec_acceptance[T09-C6/R8\u591a\u5468\u671f\u5b89\u5168\u5e26\u68c0\u6d4b\u672a\u5b9e\u73b0] |
| T10 | PASS | test_pending_spec_acceptance[T10-E2\u4e0a\u4e00\u8f6e\u9ad8\u70b9\u9009\u62e9\u672a\u5b9a\uff0c\u672a\u5b9e\u73b0] |
| T11 | PASS | test_pending_spec_acceptance[T11-E3\u65e5\u5468\u4e24\u5957\u7ed3\u6784\u5408\u5e76\u672a\u5b9a\uff0c\u672a\u5b9e\u73b0] |
| T12 | PASS | test_pending_spec_acceptance[T12-B3\u677f\u5757\u5168\u91cf\u6210\u5206\u80a1\u63a5\u53e3\u672a\u5b9e\u73b0] |
| T13 | PASS | test_pending_spec_acceptance[T13-E1\u4f9d\u8d56\u5e73\u53f0/\u5e95\u90e8\u9636\u6bb5\uff0c\u672a\u5b9e\u73b0] |
| T14 | PASS | test_pending_spec_acceptance[T14-F3\u9ad8\u4f4d\u4e2d\u7ee7\u672a\u5b9e\u73b0] |
| T15 | PASS | test_pending_spec_acceptance[T15-F3\u9ad8\u4f4d\u4e2d\u7ee7\u672a\u5b9e\u73b0] |
| T16 | PASS | test_pending_spec_acceptance[T16-F1-Y\u9f99\u95e8\u5f3a\u52bf\u7a81\u7834\u5b9a\u4e49\u6709\u6b67\u4e49\uff0c\u672a\u5b9e\u73b0] |
| T17 | PASS | test_pending_spec_acceptance[T17-R7\u51bb\u7ed3\u5386\u53f2\u8bc4\u5206\u5feb\u7167\u672a\u5b9e\u73b0] |
| T18 | PASS | test_T18_no_chip_data |
| T19 | PASS | test_T19_no_minute_data |
| T20 | SKIP | T20: 自动选股排名属于明确排除的Stage 2；不伪造通过。 |

## V1.3 新增测试

新增54项，覆盖四项最终语义、C5生命周期、版本、旧规范哈希和评分权重保持。

## 失败项

无。

## 完整性

V1.3 Word SHA256为 `99ac51b9e20e6cd2de80cd3d406d43a2d86938820c37a3dcda1ef922140a6233`。
测试仅证明已实现行为及明确的未知守卫；不证明未实现复杂规则已通过业务验收，不代表回测收益或真实行情验证。
