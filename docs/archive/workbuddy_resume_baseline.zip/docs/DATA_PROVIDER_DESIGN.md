# QuantScore Stage 2 数据 Provider 设计

## 范围

Stage 2 接入真实 A 股日线与固定上证指数基准，不改变 V1.3 评分权重和规则语义。V1.4 只新增数据契约字段：`benchmark_index=000001.SH`、`benchmark_name=上证指数`。

## 架构

```text
SymbolResolver
  -> ProviderManager
     -> AKShareProvider（默认真实源）
     -> TushareProvider（可选，只有 TUSHARE_TOKEN 且权限可用时启用）
     -> DataCache（SQLite，TTL/force_refresh）
     -> DataValidator
     -> FeatureBuilder / Weekly-Monthly Resampler
     -> StockAnalysisService
     -> RuleEngine / ScoreEngine
```

Provider 只负责外部数据和字段适配；规则只消费标准 DataFrame。Adapter 内部可使用数据源代码，系统内部必须使用 `canonical_symbol`。

## Provider 策略

- AKShare 使用运行环境实际安装版本的 `stock_zh_a_hist`（raw 与 qfq 分开获取）和 `stock_zh_index_daily_em`（`sh000001`）。
- Tushare 为增强源，不是默认硬依赖；可补充历史涨跌停和换手率。
- 单次请求有硬超时，失败最多重试 3 次；失败进入明确 `ProviderError`，不无限重试。
- 真实网络 smoke 失败必须记录 `NETWORK_FAILED`，不得以 MockProvider 冒充真实通过。

## 代码解析

- `600519`、`SH600519`、`600519.SH` 解析为 `600519.SH`。
- `000001` 按真实证券列表解析为股票 `000001.SZ`。
- `000001.SH`、`SSE_COMPOSITE`、`BENCHMARK` 解析为 INDEX 上证指数。
- 不通过代码前缀猜测交易所；无真实证券列表时拒绝裸代码。

## 缓存与降级

缓存键包含 provider、symbol、start_date、end_date、adjustment；缓存只存行情 JSON，不存 token/cookie。股票与基准可分别降级：基准缺失只使 A1/A2/A3 等依赖基准的规则 UNKNOWN；涨跌停价不可可靠确认时只影响相关规则。

## 安全边界

真实凭据只允许来自运行时环境；仓库不提交 token、cookie、API key、个人账号或大型缓存。`MockProvider` 仅用于离线测试，并通过 `is_mock=true` 显式标识。
