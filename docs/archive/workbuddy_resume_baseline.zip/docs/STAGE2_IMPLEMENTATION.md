# Stage 2 实现说明

## 已落地

- Provider 抽象、AKShare 默认适配、可选 Tushare、超时/重试。
- SymbolResolver：`600519 -> 600519.SH`、`000001 -> 000001.SZ`、`000001.SH -> INDEX`。
- raw/qfq 严格按日期合并；固定 benchmark `000001.SH / 上证指数`。
- SQLite TTL cache、force refresh、数据校验、涨跌停可靠性分级。
- 日线特征、已完成周/月聚合、as_of 截断与无未来泄漏保护。
- StockAnalysisService、FastAPI health/analyze/rules/data status、CLI JSON。
- 离线测试保留原有测试，并覆盖 provider schema、symbol、benchmark、cache、retry、周期、look-ahead 和降级。

## 规则状态

Stage 2 已完成 D2、F1-X、F2、R3、R5 的执行器、分档/依赖守卫与业务边界测试；另有 13 条规则仍明确 NOT_IMPLEMENTED。数据不可得时任何规则仍可按契约返回 UNKNOWN，不能把数据缺失误报为 FAIL 或 PASS。具体见 `docs/RULE_IMPLEMENTATION_MATRIX.md`。

## 真实网络验收

运行 smoke 必须直接调用 AKShare 实际接口，记录版本、请求代码、行数、最后交易日、字段覆盖和异常。任何代理、超时、接口字段变化或网络不可达均写入 `NETWORK_FAILED`，最终 Stage 2 状态为 `PARTIAL`；不得使用人工 fixture 代替。

## 不在本阶段

不做 Stage 3 板块扫描、自动选股排名、Web UI、收益预测/回测、筹码分布或分钟级 R6。
