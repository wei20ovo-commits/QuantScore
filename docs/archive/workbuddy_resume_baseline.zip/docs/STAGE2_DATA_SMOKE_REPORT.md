# Stage 2 真实数据 Smoke Report

- 运行日期：2026-09-26
- Provider：AKShare 1.18.97
- 真实性：直接真实网络调用；未使用 MockProvider 冒充 smoke 结果
- 固定基准：`000001.SH` / 上证指数
- 调用时间：2026-09-26 15:13:02（北京时间）；请求区间：2026-08-01 至 2026-09-25。
- 命令：`<PYTHON_ROOT>/python.exe tools/stage2_smoke.py`，项目根目录显式加入 `PYTHONPATH`。
- 本轮真实调用以 JSON 为准；证券列表成功解析两个裸代码，两个股票各 raw/qfq 请求及指数请求均因 ProxyError 失败。未使用缓存或 mock，总状态 PARTIAL。
- **网络状态：NETWORK_FAILED；5 个历史日 M5/M30/M60 与 qfq 抽查未执行**，因为股票 raw/qfq 数据未取得；不得将离线测试或 mock 结果计作真实行情通过。

| 输入 | 期望解析 | 结果 | 说明 |
|---|---|---|---|
| `600519` | `600519.SH` | NETWORK_FAILED | 股票真实接口受网络/代理错误影响 |
| `000001` | `000001.SZ` | NETWORK_FAILED | 裸代码解析目标为平安银行，真实股票接口失败 |
| `000001.SH` | `000001.SH` INDEX | NETWORK_FAILED | `stock_zh_index_daily_em` 返回 ProxyError；不能沿用旧报告的成功结论 |

股票失败没有被改写为 REAL DATA PASS，也没有用人工行情补齐。故真实 smoke 总状态为 **PARTIAL**，详细机器结果见 `outputs/smoke/stage2_smoke_report.json`。已有离线 MockProvider 测试只证明适配器契约和降级逻辑，不能替代真实网络验收。

## 数据质量核验

真实股票数据不可得时，raw/qfq、turnover、limit price、均线和 QuantScore 不报告伪造数值。网络失败原因保留在结果中；基准可独立记录，不代表股票分析成功。
