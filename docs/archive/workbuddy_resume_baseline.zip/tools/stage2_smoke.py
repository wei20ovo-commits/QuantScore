"""真实 AKShare 网络验收；不导入 MockProvider，不读取行情缓存。"""
import json
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

from app.data.akshare_provider import AKShareProvider
from app.data.models import ProviderError
from app.data.symbol import SymbolResolver
from app.data.validators import DataValidator


def main():
    provider = AKShareProvider(timeout=20)
    start, end = '2026-08-01', '2026-09-25'
    report = {'provider': 'AKShare', 'akshare_version': version('akshare'),
              'run_at': datetime.now(timezone.utc).isoformat(),
              'start_date': start, 'end_date': end, 'cache_used': False, 'cases': []}
    try:
        securities = provider.list_securities()
        resolver = SymbolResolver(securities)
        resolution_error = None
    except Exception as exc:
        resolver = None
        resolution_error = str(exc) if isinstance(exc, ProviderError) else type(exc).__name__
    for value, expected in [('600519', '600519.SH'), ('000001', '000001.SZ'), ('000001.SH', '000001.SH')]:
        case = {'input': value, 'expected_symbol': expected, 'mock_used': False, 'checks': []}
        if value != '000001.SH':
            case['symbol_resolution'] = {'status': 'NETWORK_FAILED', 'error': resolution_error} if resolver is None else {'status': 'PASS', 'symbol': resolver.resolve(value).canonical_symbol}
        for adjustment in (['index'] if value == '000001.SH' else ['raw', 'qfq']):
            check = {'adjustment': adjustment}
            try:
                data = provider.fetch_benchmark(start, end) if adjustment == 'index' else provider.fetch_stock_daily(expected, start, end, adjustment)
                if data.empty:
                    raise ValueError('EMPTY_DATA')
                check.update(status='FETCH_SUCCEEDED', rows=len(data), first_date=str(data.date.min().date()), last_date=str(data.date.max().date()))
                if adjustment == 'raw':
                    raw = data
                elif adjustment == 'qfq' and case['checks'][0]['status'] == 'FETCH_SUCCEEDED':
                    DataValidator.align_raw_qfq(raw, data)
                    check['alignment'] = 'PASS'
            except Exception as exc:
                check.update(status='NETWORK_FAILED' if isinstance(exc, ProviderError) else 'DATA_FAILED', error=str(exc) if isinstance(exc, ProviderError) else type(exc).__name__)
            case['checks'].append(check)
        statuses = [c['status'] for c in case['checks']]
        if case.get('symbol_resolution', {}).get('status') == 'NETWORK_FAILED':
            statuses.append('NETWORK_FAILED')
        case['status'] = 'NETWORK_FAILED' if 'NETWORK_FAILED' in statuses else ('DATA_FAILED' if 'DATA_FAILED' in statuses else 'FETCH_SUCCEEDED')
        report['cases'].append(case)
    report['status'] = 'PASS' if all(c['status'] == 'FETCH_SUCCEEDED' for c in report['cases']) else 'PARTIAL'
    path = Path(__file__).resolve().parents[1] / 'outputs/smoke/stage2_smoke_report.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    main()
