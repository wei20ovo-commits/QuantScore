from dataclasses import asdict, dataclass, field
from enum import StrEnum
import json


class Status(StrEnum):
    PASS = 'PASS'
    PARTIAL = 'PARTIAL'
    FAIL = 'FAIL'
    UNKNOWN = 'UNKNOWN'
    CANDIDATE = 'CANDIDATE'
    FORMED = 'FORMED'
    CONFIRMED = 'CONFIRMED'
    INVALIDATED = 'INVALIDATED'


class SourceType(StrEnum):
    AUTO = 'AUTO'
    AUTO_PROXY = 'AUTO_PROXY'
    AUTO_IF_DATA = 'AUTO_IF_DATA'
    MANUAL = 'MANUAL'


class RuleType(StrEnum):
    POSITIVE = 'POSITIVE'
    RISK = 'RISK'
    SECTOR = 'SECTOR'
    SYSTEM = 'SYSTEM'


@dataclass
class RuleResult:
    rule_id: str
    name_cn: str
    category: str
    rule_type: RuleType
    source_type: SourceType
    status: Status
    score: float | None
    max_score: float
    penalty: float | None
    max_penalty: float
    raw_values: dict = field(default_factory=dict)
    conditions: dict = field(default_factory=dict)
    explanation: str = ''
    spec_version: str = '1.1'
    assumption_version: str = 'v1.1'
    code_status: str = 'NOT_IMPLEMENTED'
    reason_code: str | None = None
    event_id: str | None = None
    applicable: bool | None = None
    source_note_pages: str = ''
    adjustments: list = field(default_factory=list)

    def __post_init__(self):
        self.status = Status(self.status)
        self.source_type = SourceType(self.source_type)
        self.rule_type = RuleType(self.rule_type)
        if self.status == Status.UNKNOWN and (self.score is not None or self.penalty is not None):
            raise ValueError('UNKNOWN must have null score and penalty')
        for value, maximum in ((self.score, self.max_score), (self.penalty, self.max_penalty)):
            if value is not None and not 0 <= value <= maximum:
                raise ValueError('Result outside specification bounds')
        if not self.explanation:
            raise ValueError('Explanation is required')

    def to_dict(self):
        # Fail loudly if a handler leaks NaN, infinity or non-JSON data.
        return json.loads(json.dumps(asdict(self), ensure_ascii=False, allow_nan=False))
