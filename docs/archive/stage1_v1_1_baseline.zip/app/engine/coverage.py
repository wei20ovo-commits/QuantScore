from collections import Counter


def calculate(results,parameters):
    """Literal PositiveCoverage, without normalizing known scores to 100.

    Risk applicability is tri-state. Unknown denominators produce a range,
    never a made-up exact RiskCoverage.
    """
    positives=[r for r in results if r.rule_type=='POSITIVE']
    risks=[r for r in results if r.rule_type=='RISK']
    successful={'PASS','PARTIAL','FAIL'}
    weight=sum(r.max_score for r in positives if r.status in successful)
    fraction=weight/parameters['SYSTEM']['positive_cap']
    # All F1 capacities together exceed the 100-point system capacity. The
    # specification does not define a coverage-group cap; do not invent one.
    exact_positive=fraction if fraction<=1 else None
    breakdown={}
    for label,group in [('positive',positives),('risk',risks)]:
        breakdown[label]={
            'successful_judgment':sum(r.status in successful for r in group),
            'data_insufficient':sum(r.reason_code in ('DATA_INSUFFICIENT','INVALID_DATA','ADJUSTMENT_UNVERIFIED') for r in group),
            'manual':sum(r.source_type=='MANUAL' for r in group),
            'unknown':sum(r.status=='UNKNOWN' for r in group),
            'not_implemented':sum(r.code_status=='NOT_IMPLEMENTED' for r in group),
            'partial_implementation':sum(r.code_status=='PARTIAL' for r in group),
            'status_counts':dict(Counter(str(r.status) for r in group))}
    applicable=[r for r in risks if r.applicable is True]
    undecided=[r for r in risks if r.applicable is None]
    known=sum(r.status!='UNKNOWN' for r in applicable)
    denominator=len(applicable)
    exact_risk=known/denominator if denominator and not undecided else None
    lower=known/(denominator+len(undecided)) if denominator+len(undecided) else None
    upper=known/denominator if denominator else None
    return {'positive_coverage':exact_positive,'coverage':None if exact_positive is None else exact_positive*100,
            'positive_successful_max_score':weight,'positive_denominator':parameters['SYSTEM']['positive_cap'],
            'risk_coverage':exact_risk,'risk_coverage_lower_bound':lower,'risk_coverage_upper_bound':upper,
            'risk_applicable_count':denominator,'risk_unknown_applicability_count':len(undecided),
            'breakdown':breakdown,'coverage_note':'按第8.1节，正向仅统计PASS/PARTIAL/FAIL；形态状态不擅自映射。风险适用性未决时精确覆盖率为null。',
            'ambiguity':'F1最大分值合计使Coverage超过100%；规范未定义分组分母' if exact_positive is None else None}
