"""Every chapter-11 acceptance ID is visible; unfinished work is SKIP, not PASS."""
import pytest
from app.rules.base import Context
from app.engine.score_engine import ScoreEngine
from conftest import bars,evaluate,n_board,double_top


def test_T01_short_M60_history(engine):
    d=bars([10]*59)
    for rid in ['C1','C2','C3','C4']:
        assert evaluate(engine,rid,d).status=='UNKNOWN'
    assert ScoreEngine(engine).evaluate(Context(d))['coverage']<100


def test_T03_n_intraday_break(engine):
    d=n_board(broken=True)
    assert evaluate(engine,'F1-N',d).status=='INVALIDATED'
    assert evaluate(engine,'R11',d).penalty==8


def test_T04_n_second_start(engine):
    assert evaluate(engine,'F1-N',n_board(confirmed=True)).score==10


def test_T06_double_top_invalidated(engine):
    r=evaluate(engine,'R4',double_top('INVALIDATED'),adjustment_consistent=True)
    assert r.status=='INVALIDATED' and r.penalty==0


def test_T07_double_top_confirmed(engine):
    r=evaluate(engine,'R4',double_top('CONFIRMED'),adjustment_consistent=True)
    assert r.status=='CONFIRMED' and r.penalty==12


def test_T18_no_chip_data(engine):
    for rid in ['E4','E5','R10']:
        assert evaluate(engine,rid,bars([10]*150)).status=='UNKNOWN'


def test_T19_no_minute_data(engine):
    assert evaluate(engine,'R6',bars([10]*150)).status=='UNKNOWN'


@pytest.mark.parametrize('test_id,reason',[
 ('T02','C5平台多数日/工程边界未定，未实现'),
 ('T05','F1-T部分T形几何未定，未实现'),
 ('T08','C6/R8多周期安全带检测未实现'),
 ('T09','C6/R8多周期安全带检测未实现'),
 ('T10','E2上一轮高点选择未定，未实现'),
 ('T11','E3日周两套结构合并未定，未实现'),
 ('T12','B3板块全量成分股接口未实现'),
 ('T13','E1依赖平台/底部阶段，未实现'),
 ('T14','F3高位中继未实现'),
 ('T15','F3高位中继未实现'),
 ('T16','F1-Y龙门强势突破定义有歧义，未实现'),
 ('T17','R7冻结历史评分快照未实现'),
 ('T20','用户要求Stage 1不开发自动选股')])
def test_pending_spec_acceptance(test_id,reason):
    pytest.skip(f'{test_id}: {reason}')
