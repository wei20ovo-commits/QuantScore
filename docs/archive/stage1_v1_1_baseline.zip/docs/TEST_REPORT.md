# 实际测试报告

- 总数：182
- PASS：169
- FAIL/ERROR：0
- SKIP：13
- 实际命令：`python -m pytest --junitxml=outputs/pytest-results.xml`
- 环境：Python 3.11.0；依赖版本见requirements.txt；人工构造OHLCV；核心测试不联网。
- 原始结果：outputs/pytest-results.xml；跳过不等于通过。

## 第11章最低验收

| ID | 状态 | 证据/原因 |
|---|---|---|
| T01 | PASS | test_T01_short_M60_history |
| T02 | SKIP | T02: C5平台多数日/工程边界未定，未实现 |
| T03 | PASS | test_T03_n_intraday_break |
| T04 | PASS | test_T04_n_second_start |
| T05 | SKIP | T05: F1-T部分T形几何未定，未实现 |
| T06 | PASS | test_T06_double_top_invalidated |
| T07 | PASS | test_T07_double_top_confirmed |
| T08 | SKIP | T08: C6/R8多周期安全带检测未实现 |
| T09 | SKIP | T09: C6/R8多周期安全带检测未实现 |
| T10 | SKIP | T10: E2上一轮高点选择未定，未实现 |
| T11 | SKIP | T11: E3日周两套结构合并未定，未实现 |
| T12 | SKIP | T12: B3板块全量成分股接口未实现 |
| T13 | SKIP | T13: E1依赖平台/底部阶段，未实现 |
| T14 | SKIP | T14: F3高位中继未实现 |
| T15 | SKIP | T15: F3高位中继未实现 |
| T16 | SKIP | T16: F1-Y龙门强势突破定义有歧义，未实现 |
| T17 | SKIP | T17: R7冻结历史评分快照未实现 |
| T18 | PASS | test_T18_no_chip_data |
| T19 | PASS | test_T19_no_minute_data |
| T20 | SKIP | T20: 用户要求Stage 1不开发自动选股 |

## 失败项

无。

## 完整性

Word SHA256仍为 `79ec2876cd3658a2ae9da2fab3a397c9b192d98d39058cb6ed60c0e7448b0a8b`。
测试仅证明已实现行为及明确的未知守卫；不证明未实现复杂规则已通过业务验收，不代表回测收益或真实行情验证。
