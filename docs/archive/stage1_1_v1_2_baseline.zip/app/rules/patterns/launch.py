from app.rules.base import require,indicators,result,divide,high_zone,UnknownData


def price_shapes(d,p):
    require(d,['open_raw','high_raw','low_raw','close_raw','limit_up_price'],1)
    row=d.iloc[-1]; limit=float(row.limit_up_price); tol=p['GLOBAL']['near_limit_tol']; q=p['F1-O']
    final=bool(row.close_raw>=limit*(1-tol)); touch=bool(row.high_raw>=limit*(1-tol))
    opened=bool(row.low_raw<=limit*p['F1-T']['open_board_ratio'])
    near_all=all(abs(float(row[field])/limit-1)<=q['price_tolerance'] for field in ('open_raw','high_raw','close_raw'))
    one_line=near_all and (row.high_raw-row.low_raw)/limit<=q['one_line_range_max']
    one_t=near_all and row.low_raw<=limit*q['one_t_low_ratio']
    return {'final_limit':final,'touch_limit':touch,'opened_at_least_2pct':opened,'t_shape':final and touch and opened,
            'one_line':bool(one_line),'one_line_t':bool(one_t)}, {k:float(row[k]) for k in ['open_raw','high_raw','low_raw','close_raw','limit_up_price']}


def abnormal_trade(d,p):
    w=p['GLOBAL']['volume_window']; require(d,['volume','turnover_rate'],w+1)
    vr=divide(d.volume.iloc[-1],d.volume.iloc[-w-1:-1].mean()); turn=float(d.turnover_rate.iloc[-1]); q=p['R12']
    # Continuous tier threshold is left-closed in V1.2.
    abnormal_turn=turn>=q['turnover_threshold']; abnormal_volume=vr>=q['volume_threshold']
    return q['penalties'][int(abnormal_turn)+int(abnormal_volume)],{'volume_ratio_20':vr,'turnover_rate_pct':turn}, {'abnormal_turnover':abnormal_turn,'abnormal_volume':abnormal_volume}


def f1t(ctx,rule,p):
    shape,raw=price_shapes(ctx.bars,p)
    # Price recognition is independent of trading abnormalities; cancellation
    # is exclusively handled by R12 + the conflicts layer.
    return result(rule,score=p['F1-T']['scores'][1] if shape['t_shape'] else 0,raw={**raw,'event_date':str(ctx.bars.date.iloc[-1].date())},conditions=shape,
                  explanation='按收盘封停、最高价触停、最低价较涨停价至少低2%识别完整T板；不要求开盘涨停。异常成交由R12另评。')


def f1o(ctx,rule,p):
    shape,raw=price_shapes(ctx.bars,p); q=p['F1-O']; w=p['GLOBAL']['volume_window']
    if not (shape['one_line'] or shape['one_line_t']):
        return result(rule,raw=raw,conditions=shape,explanation='一字板及一字T价格结构均不成立。')
    high,position=high_zone(ctx.bars,p)
    if high: return result(rule,raw={**raw,**position},conditions={**shape,'HIGH_ZONE':True},explanation='高位不适用干净底部启动，得0分。')
    require(ctx.bars,['volume','turnover_rate'],w+1)
    reference=float(ctx.bars.volume.iloc[-w-1:-1].mean()); prior=float(ctx.bars.volume.iloc[-q['pre_days']-1:-1].mean())
    clean_pre=prior<=reference*q['one_word_pre_volume_ratio']; turn=float(ctx.bars.turnover_rate.iloc[-1])
    current_vr=divide(ctx.bars.volume.iloc[-1],reference); clean_turn=turn<=q['one_word_max_turnover_pct']
    abnormal,_,_=abnormal_trade(ctx.bars,p)
    score=q['scores'][3] if shape['one_line'] and clean_pre and clean_turn and current_vr<=q['volume_ratio_max'] else q['scores'][2] if shape['one_line_t'] and clean_pre and clean_turn else q['scores'][1] if not clean_pre else 0
    raw.update(previous3_mean=prior,previous20_mean=reference,volume_ratio_20=current_vr,turnover_rate_pct=turn,event_date=str(ctx.bars.date.iloc[-1].date()))
    if abnormal: score=0
    # The legacy table gives +2 only for prior volume expansion. It does not
    # define a non-full score for clean prior volume but 5%<turn<abnormal.
    if clean_pre and not clean_turn and not abnormal:
        return result(rule,'UNKNOWN',raw=raw,conditions={**shape,'clean_turnover':False},reason_code='USER_DECISION_REQUIRED',explanation='换手>5%不能给干净启动满分；V1.1未给此单独分支的PARTIAL分值，待用户明确。')
    return result(rule,score=score,raw=raw,conditions={**shape,'pre_volume_clean':clean_pre,'clean_turnover':clean_turn,'R12_abnormal':bool(abnormal)},explanation=f'前3日均量不超过前20日均量1.2倍={clean_pre}，换手不超过5%={clean_turn}；得{score}分。')


def r12(ctx,rule,p):
    shapes,raw=price_shapes(ctx.bars,p)
    candidate=shapes['t_shape'] or shapes['one_line'] or shapes['one_line_t']
    if not candidate:
        return result(rule,raw=raw,conditions={'applicable_pattern':False},applicable=False,explanation='无T板/一字板候选，R12前置明确不成立。')
    penalty,trade,conditions=abnormal_trade(ctx.bars,p)
    return result(rule,penalty=penalty,raw={**raw,**trade},conditions=conditions,applicable=True,explanation=f'T/一字候选的异常成交独立扣{penalty}分；对应正分由冲突层取消。')


def f3(ctx,rule,p):
    q=p['F3']; w=p['GLOBAL']['volume_window']; require(ctx.bars,['close_adj','high_adj','low_adj','volume','close_raw','limit_up_price'],w+q['search_days'])
    d=indicators(ctx.bars,p); events=[]; missing_high=False
    for j in reversed(range(len(d)-q['search_days'],len(d))):
        vr=divide(d.volume.iloc[j],d.volume.iloc[j-w:j].mean())
        near=bool(d.close_raw.iloc[j]>=d.limit_up_price.iloc[j]*(1-p['GLOBAL']['near_limit_tol']))
        if not near or vr>q['low_volume_limit_ratio20']: continue
        ret20=divide(d.close_adj.iloc[j],d.close_adj.iloc[j-20])-1
        try: high=ret20>=p['GLOBAL']['high_zone_ret20'] or high_zone(d,p,j)[0]
        except UnknownData: missing_high=True; continue
        if not high: continue
        ref=float(d.volume.iloc[max(0,j-q['rise_reference_days']+1):j+1].mean()); rows=[]; event=None
        for k in range(j+1,min(len(d),j+q['exchange_days_max']+2)):
            length=k-j-1
            if q['exchange_days_min']<=length<=q['exchange_days_max']:
                exchange=d.iloc[j+1:k]; ratio=divide(exchange.volume.mean(),ref)
                ret=divide(d.close_adj.iloc[k],d.close_adj.iloc[k-1])-1
                continuation=bool(d.close_adj.iloc[k]>exchange.high_adj.max() or (ret>=q['continuation_return_proxy'] and d.close_adj.iloc[k]>d.M5.iloc[k]))
                if ratio>=q['exchange_volume_vs_rise_min'] and continuation:
                    event={'status':'CONFIRMED','score':q['scores_by_days'][length],'L':length,'exchange_ratio':ratio,'event_date':str(d.date.iloc[k].date())}; break
            if k-j>q['exchange_days_max']:
                event={'status':'INVALIDATED','score':0,'reason':'EXPIRED'}; break
            rows.append({'date':str(d.date.iloc[k].date()),'low':float(d.low_adj.iloc[k]),'M5':float(d.M5.iloc[k]),'volume':float(d.volume.iloc[k])})
            if d.low_adj.iloc[k]<d.M5.iloc[k]:
                event={'status':'INVALIDATED','score':0,'reason':'M5_HARD_BREAK'}; break
        if event is None:
            ratio=divide(sum(r['volume'] for r in rows)/len(rows),ref) if rows else 0
            legal=len(rows)>=q['exchange_days_min'] and ratio>=q['exchange_volume_vs_rise_min']
            event={'status':'CANDIDATE','score':q['candidate_score'] if legal else 0,'L':len(rows),'exchange_ratio':ratio}
        event.update(first_start_date=str(d.date.iloc[j].date()),rise_volume_ref=ref,exchange_days=rows)
        events.append(event)
    if not events:
        if missing_high: raise UnknownData('低量涨停存在，但高位前置历史不足')
        return result(rule,raw={'searched_days':q['search_days']},conditions={'first_start':False},explanation='未找到高位低量涨停后的合法中继结构。')
    event=next((e for e in events if e['status']=='CONFIRMED'),events[0])
    return result(rule,event['status'],score=event['score'],raw=event,conditions={'m5_integrity':event.get('reason')!='M5_HARD_BREAK','continuation':event['status']=='CONFIRMED'},event_id='F3:'+event['first_start_date'],explanation=f'低量涨停后2~6日放量整理、盘中M5不破；状态{event["status"]}，得{event["score"]}分。')
