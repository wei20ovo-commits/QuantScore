import bisect
from app.rules.base import require, indicators, divide, result, high_zone


def r1(ctx,rule,p):
    require(ctx.bars,['turnover_rate'],1); high,raw=high_zone(ctx.bars,p)
    turn=float(ctx.bars.turnover_rate.iloc[-1]); q=p['R1']
    penalty=q['penalties'][bisect.bisect_right(q['turnover_levels'],turn)] if high else 0
    return result(rule,penalty=penalty,raw={**raw,'turnover_rate_pct':turn},conditions={'HIGH_ZONE':bool(high),'hard_high':bool(high and turn>=q['hard_high_turnover'])},applicable=bool(high),explanation=f'高位={high}，换手率{turn:.2f}%，仅扣最高档{penalty}分。')


def r2(ctx,rule,p):
    w=p['GLOBAL']['volume_window']; require(ctx.bars,['volume'],w+1); high,raw=high_zone(ctx.bars,p)
    volume=float(ctx.bars.volume.iloc[-1]); mean=float(ctx.bars.volume.iloc[-w-1:-1].mean()); vr=divide(volume,mean); q=p['R2']
    penalty=q['penalties'][bisect.bisect_right(q['volume_levels'],vr)] if high else 0
    return result(rule,penalty=penalty,raw={**raw,'volume':volume,'previous_mean_volume':mean,'volume_ratio_20':vr},conditions={'HIGH_ZONE':bool(high)},applicable=bool(high),explanation=f'高位={high}，量比{vr:.2f}，仅扣最高档{penalty}分。')


def r9(ctx,rule,p):
    # 33 closes also establish whether the earlier break was a single-day event.
    require(ctx.bars,['close_adj','low_adj'],33); d=indicators(ctx.bars,p); q=p['R9']
    below=(d.close_adj<d.M30*(1-q['m30_break_margin']))
    now=bool(below.iloc[-1]); prior=bool(below.iloc[-2])
    recovered=bool(d.close_adj.iloc[-1]>d.M30.iloc[-1]*(1+q['reclaim_margin']))
    single_prior=any(bool(below.iloc[-1-k]) and not bool(below.iloc[-2-k])
                     and not bool(below.iloc[-k:-1].any())
                     for k in range(1,q['reclaim_days']+1))
    raw={'close':d.close_adj.tail(3).tolist(),'low':d.low_adj.tail(3).tolist(),'M30':d.M30.tail(3).tolist()}
    conditions={'below_today':now,'below_yesterday':prior,'recovered':recovered,'single_break_in_recovery_window':single_prior}
    if recovered and single_prior:
        return result(rule,'INVALIDATED',raw=raw,conditions=conditions,applicable=True,explanation='原单日M30破位在2日内收盘超过M30的101%，当前原事件失效，扣0分。')
    warning=bool(d.low_adj.iloc[-1]<d.M30.iloc[-1] and d.close_adj.iloc[-1]>=d.M30.iloc[-1])
    penalty=q['penalties'][3 if now and prior else 2 if now else 1 if warning else 0]
    return result(rule,penalty=penalty,raw=raw,conditions={**conditions,'intraday_warning':warning},applicable=True,explanation=f'M30有效跌破当日={now}，前日={prior}；盘中警告={warning}，仅扣{penalty}分。')
