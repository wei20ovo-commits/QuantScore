"""Build audit artifacts only from actual source/config and pytest XML."""
from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib
import json
import yaml

ROOT=Path(__file__).resolve().parents[1]
registry=yaml.safe_load((ROOT/'config/scoring_rules.yaml').read_text(encoding='utf-8'))['rules']
from zipfile import ZipFile
old_manifest=yaml.safe_load(ZipFile(ROOT/'docs/archive/stage1_v1_1_baseline.zip').read('docs/SPEC_MANIFEST.yaml'))
old_doc=ROOT/'docs/QuantScore_V1.1_机器可执行评分规则规范_用户规则补全版.docx'
assert hashlib.sha256(old_doc.read_bytes()).hexdigest()==old_manifest['sha256'], 'V1.1 changed'
doc=ROOT/'docs/QuantScore_V1.2_机器可执行评分规则规范_歧义清零版.docx'
with ZipFile(doc) as z:
    xml=ET.fromstring(z.read('word/document.xml'))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    paragraphs=[''.join(t.text or '' for t in node.findall('.//w:t',ns)) for node in xml.findall('.//w:p',ns)]
manifest={'spec_version':'1.2','sha256':hashlib.sha256(doc.read_bytes()).hexdigest(),
          'v1_1_sha256_unchanged':old_manifest['sha256'],'paragraph_count':len(paragraphs),'rule_count':len(registry)}
(ROOT/'docs/SPEC_MANIFEST.yaml').write_text(yaml.safe_dump(manifest,allow_unicode=True,sort_keys=False),encoding='utf-8')
(ROOT/'docs/SPEC_V1_2_EXTRACTED.txt').write_text('\n'.join(paragraphs),encoding='utf-8')
tree=ET.parse(ROOT/'outputs/pytest-results.xml')
cases=tree.findall('.//testcase')
failed=[c for c in cases if c.find('failure') is not None or c.find('error') is not None]
skipped=[c for c in cases if c.find('skipped') is not None]
passed=len(cases)-len(failed)-len(skipped)
all_green=not failed

lines=['# Rule Implementation Matrix','',
       'Spec Status=FROZEN_V1_2表示定义来自冻结Word，不代表代码完成。IMPLEMENTED执行已明确分支，歧义仍保守UNKNOWN；PARTIAL仅声明已列出的子行为。',
       'Test Status只针对评分执行器：未实现规则的UNKNOWN守卫测试即使通过，仍标NOT_TESTED，不冒充业务验收通过。PARTIAL规则的PASS仅表示已实现分支测试通过，不表示用户决策项已解决。','',
       '| Rule ID | 名称 | Source Type | Spec Status | Code Status | Test Status |',
       '|---|---|---|---|---|---|']
for r in registry:
    test='PASS' if all_green and r['evaluator'] else 'FAIL' if r['evaluator'] else 'NOT_TESTED'
    lines.append(f'| {r["rule_id"]} | {r["name_cn"]} | {r["source_type"]} | {r["spec_status"]} | {r["code_status"]} | {test} |')
lines+=['','## 数量','']
for state in ['IMPLEMENTED','PARTIAL','NOT_IMPLEMENTED']:
    group=[r['rule_id'] for r in registry if r['code_status']==state]
    lines.append(f'- {state}: {len(group)} — '+', '.join(group))
lines+=['','R6原文source_type=AUTO_IF_MINUTE_DATA，注册时规范化为AUTO_IF_DATA并保留source_type_in_spec。',
        '均线/量比等派生变量不新增评分Rule ID。MANUAL和SYSTEM受Schema支持，但不凭空增加规范中没有的规则。']
(ROOT/'docs/RULE_IMPLEMENTATION_MATRIX.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

lines=['# 实际测试报告','',f'- 总数：{len(cases)}',f'- PASS：{passed}',f'- FAIL/ERROR：{len(failed)}',f'- SKIP：{len(skipped)}',
       '- 实际命令：`python -m pytest --junitxml=outputs/pytest-results.xml`',
       '- 环境：Python 3.11.0；依赖版本见requirements.txt；人工构造OHLCV；核心测试不联网。', '- Stage 1原182项场景全部保留；端点/状态等预期按用户V1.2明文迁移，原件归档。',
       '- 原始结果：outputs/pytest-results.xml；跳过不等于通过。','',
       '## 第11章最低验收','',
       '| ID | 状态 | 证据/原因 |','|---|---|---|']
for i in range(1,21):
    tid=f'T{i:02}'
    matches=[c for c in cases if tid in c.attrib['name']]
    assert len(matches)==1,(tid,len(matches))
    c=matches[0]
    skip=c.find('skipped'); failure=c.find('failure'); error=c.find('error')
    state='SKIP' if skip is not None else 'FAIL' if failure is not None or error is not None else 'PASS'
    reason=skip.attrib.get('message','') if skip is not None else c.attrib['name']
    lines.append(f'| {tid} | {state} | {reason} |')
lines+=['','## 失败项','']+[c.attrib['name'] for c in failed or []]
if not failed: lines.append('无。')
lines+=['','## 完整性','',f'V1.2 Word SHA256为 `{manifest["sha256"]}`。',
        '测试仅证明已实现行为及明确的未知守卫；不证明未实现复杂规则已通过业务验收，不代表回测收益或真实行情验证。']
(ROOT/'docs/TEST_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

props={
 'rule_id':{'type':'string'},'name_cn':{'type':'string'},'category':{'type':'string'},
 'rule_type':{'enum':['POSITIVE','RISK','SECTOR','SYSTEM']},
 'source_type':{'enum':['AUTO','AUTO_PROXY','AUTO_IF_DATA','MANUAL']},
 'status':{'enum':['PASS','PARTIAL','FAIL','UNKNOWN','CANDIDATE','FORMED','CONFIRMED','INVALIDATED']},
 'score':{'type':['number','null'],'minimum':0},'max_score':{'type':'number','minimum':0},
 'penalty':{'type':['number','null'],'minimum':0},'max_penalty':{'type':'number','minimum':0},
 'raw_values':{'type':'object'},'conditions':{'type':'object'},'explanation':{'type':'string','minLength':1},
 'spec_version':{'const':'1.2'},'assumption_version':{'const':'v1.2'},
 'code_status':{'enum':['IMPLEMENTED','PARTIAL','NOT_IMPLEMENTED']},
 'reason_code':{'type':['string','null']},'event_id':{'type':['string','null']},
 'exit_risk_alert':{'type':'boolean'},'alert_type':{'type':['string','null']},'alert_text':{'type':['string','null']},'applicable':{'type':['boolean','null']},'source_note_pages':{'type':'string'},'adjustments':{'type':'array'}}
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'QuantScore RuleResult v1.2',
        'type':'object','properties':props,'required':list(props),'additionalProperties':False,
        'allOf':[{'if':{'properties':{'status':{'const':'UNKNOWN'}}},'then':{'properties':{'score':{'type':'null'},'penalty':{'type':'null'}}}}]}
(ROOT/'docs/RULE_RESULT.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary={'total':len(cases),'pass':passed,'fail':len(failed),'skip':len(skipped),'spec_sha256':manifest['sha256']}
(ROOT/'outputs/test-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
