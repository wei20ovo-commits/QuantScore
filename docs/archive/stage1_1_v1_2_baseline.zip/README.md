# QuantScore

QuantScore 是一个可解释的股票技术面策略匹配评分系统。它回答“当前股票有多符合这套交易规则，以及为什么得到这个分数”，用于展示规则建模、数据契约、可解释计算和测试工程能力。输出不包含涨跌预测、买卖推荐或收益承诺。

先固定评分规范，再写代码，能够防止实现过程悄悄改变策略。`docs/QuantScore_V1.2_机器可执行评分规则规范_歧义清零版.docx` 是唯一规则真源（Single Source of Truth）。配置和文本提取都是其派生物；遇到歧义保守返回 UNKNOWN，详见 [歧义记录](docs/RULE_AMBIGUITIES.md)。本轮创建V1.2 Word；原V1.1 Word未修改，旧代码、配置和182项测试归档于docs/archive/stage1_v1_1_baseline.zip。文件名不表示四项待确认语义已经清零。

## Stage 1.1 当前范围

48条规则全部登记：26条IMPLEMENTED、4条PARTIAL、18条NOT_IMPLEMENTED。

- 已实现：A1/A2/A3、B3、C1–C6、D1/D3/D4/D5、E2/E3、F1-N/F1-T/F3、R1/R2/R4/R8/R9/R11/R12。
- 部分实现：E1、F1-O、F1-Y、R7。已明确分支执行，未确认分支返回UNKNOWN。
- 未实现：S1–S7、B1/B2、D2、E4/E5、F1-X、F2、R3/R5/R6/R10。
- RuleEngine、ScoreEngine、统一Schema、互斥取消、风险去重和Coverage已建立。
- R4按最近P2及同P2最小峰差选择，候选开始提醒、失效撤销；N板从近到远选择完整合法结构，盘中破M5不可恢复。

详见[实现矩阵](docs/RULE_IMPLEMENTATION_MATRIX.md)、[双顶验证](docs/DOUBLE_TOP_VERIFICATION.md)和[用户决策项](docs/USER_DECISIONS_REQUIRED.md)。未确认分支的UNKNOWN测试不代表整条规则完整验收。

## 运行

Python 3.11及以上。在本项目目录内使用独立环境：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest
```

本次工作空间为避免修改共享Python环境，将依赖安装在项目 `.deps`。复现这次测试可使用：

```powershell
$env:PYTHONPATH = ((Join-Path (Get-Location) '.deps') + ';' + (Get-Location).Path)
python -m pytest
```

核心测试仅使用固定人工构造的OHLCV DataFrame，不联网、不伪装真实股票行情。Word验收20个场景全部有测试入口；未完成的验收以显式SKIP保留，不能算PASS。实际数量见 [测试报告](docs/TEST_REPORT.md) 与 `outputs/pytest-results.xml`。

## 接口

```python
from app.rules.base import Context
from app.engine.rule_engine import RuleEngine
from app.engine.score_engine import ScoreEngine

# stock_bars、benchmark_bars由调用方提供；项目不接入真实行情。
context = Context(
    bars=stock_bars,
    benchmark=benchmark_bars,
    as_of="2024-06-28",
    metadata={"adjustment_consistent": True},
)
detail = RuleEngine().evaluate("R4", context).to_dict()
report = ScoreEngine().evaluate(context)
```

DataFrame必须包含升序、唯一的交易日 `date`（或DatetimeIndex）；只接受已完成日线。复权价为 `open_adj/high_adj/low_adj/close_adj`，原始价为 `*_raw`，数量字段为 `volume`，换手率 `turnover_rate` 用百分点（5代表5%），真实涨停价用 `limit_up_price`。不能以raw替换缺失的adj，也不能把涨停幅度统一写成10%。测试中提供的涨停价只是人工构造字段。

每条规则输出原始值、条件、说明、版本、实现状态和事件ID。UNKNOWN的score/penalty为null；FAIL是已能判断且未满足。MANUAL来源被引擎强制拦截为UNKNOWN，本规范没有需要新增的MANUAL规则，所以测试只修改测试内副本验证此防线，不往规则库增造规则。

`as_of`先截断股票和基准，再执行所有计算。局部峰右侧确认只能读取评价日以前的K线。调用方仍需保证提供的是当时可得的复权序列；本项目没有历史复权快照服务。

## 汇总与Coverage

正向按A/B/C/D/E/F的10/15/25/20/15/15分封顶，总正向不超过100。F1只取单项最高分，F2依赖F1；风险先取消冲突正分，再按每项最高严重度扣分。完全重复的规则结果只计一次，不同内容的重复结果拒绝输入。FinalQuantScore=max(0,PositiveScore−RiskPenalty)。

不把已知规则得分归一化为100。所有未知规则仍在明细中；汇总数值仅代表已确定的分数贡献。`is_partial_result`显式表示缺项。Coverage低于70%时match_level=null，只提供规则明细及已知贡献，不能作为完整等级展示。

PositiveCoverage将七种确定状态计入，UNKNOWN和未实现不计；按最大分值及分类上限计算，F1贡献最多10、F类最多15。RiskCoverage分母为本次执行的风险全集，包含前置不成立、缺数据及未实现规则；空集合返回1并标记empty_execution_set。Coverage始终为数值。风险等级只描述已执行风险，不表示未知风险不存在。

周/月规则只读取已完成周期，可通过metadata.period_bars的W/M DataFrame提供，包含周期收盘date及is_complete；否则聚合已结束日历周期。调用方负责交易日与历史数据可得性。R7通过ScoreSnapshot.freeze(report, bars)冻结历史信号，随后等待3个完整交易日，未来表现不会回写历史评分。

## 项目结构

```text
config/                  48条规则登记、数值参数与原文分档
app/models/              状态枚举与统一结果Schema
app/rules/               基础趋势、量价、风险、双顶与N板执行器
app/engine/              单条执行、汇总、Coverage、冲突处理
tests/                   固定OHLCV与规范验收测试
tools/                   只读规范解析、登记补全、报告生成
docs/                    原Word、提取文本、歧义、矩阵与测试报告
outputs/                 实际测试结果
```

旧版解析器已禁止覆盖V1.2配置。修改规则必须先升版规范。`python -m tools.generate_reports`读取实际pytest XML更新报告；不会自行宣称测试通过。原182项场景保留并按V1.2迁移预期；仅T20自动排名属于Stage 2，继续显式跳过。

## 当前限制

当前没有前端、网络行情、板块热度执行、自动选股、回测或历史收益结果。复杂规则未以近似实现冒充完整实现。部分规范分档和状态存在歧义；完整列表及保守行为见歧义记录。自动执行结果不能替代对输入来源和复权口径的核查。

## Future Work

真实A股行情接入、完整单股分析、Sector Heat Score、风口板块识别、板块成分股自动筛选、AutoScore、Web Demo、用户反馈、回测与规则迭代均为后续工作，尚未完成。当前停止在Stage 1.1。
