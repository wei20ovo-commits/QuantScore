# QuantScore Stage2 最终 QA 与交付报告

## Executive Summary

本轮独立 QA 在项目 `LOCAL_PRIVATE_PATH 内完成。发现并修复 CLI 文本输出缺少 Coverage、Top Positive Rules、Top Risk Rules、Unknown Rules 的缺陷，并修复新增输出逻辑对规则明细 dict 使用属性访问导致的回归。修复后全量测试通过：374 项，373 passed、1 skipped、0 failed、1 warning。真实 AKShare smoke 未通过网络代理，三 symbol 均为 `NETWORK_FAILED`，因此最终状态为 **PARTIAL**。

## Resume / Existing Work Audit

交接材料与实际代码均核验；原 295 测试保留证据为 295/295，权重未改变证据为 `weights_unchanged=true`。本轮不使用 git，不初始化仓库、不 reset、不提交。

## V1.4 Spec

V1.4 固定数据契约与 benchmark，继承 V1.3 评分语义；运行结果的 `spec_version` 为 1.4，`assumption_version` 为 v1.3。V1.1/V1.2/V1.3 Word 原件保留，旧继承文字须视为历史对照。

## Benchmark

固定 `000001.SH` / `上证指数`。裸 `000001` 通过证券表解析为 `000001.SZ`，不可按前缀猜交易所。

## Provider Architecture

Provider 抽象、SQLite 缓存、TTL、有限重试、force refresh 与硬超时均保留；AKShare 为默认真实源，Tushare 为可选增强源。

## AKShare Integration

股票 raw 使用空 adjustment，qfq 使用 `qfq`；指数使用 `stock_zh_index_daily_em`。真实调用受 ProxyError 限制。

## Tushare Optional Integration

Tushare 仅在 token 可用时作为增强源；`.env.example` 唯一内容为 `TUSHARE_TOKEN=`，未配置不阻断默认流程。

## Symbol Resolution

离线与 smoke 均核验 `600519 -> 600519.SH`、`000001 -> 000001.SZ`、`000001.SH -> INDEX`。

## Raw / Adjusted Data

raw/qfq 分别获取并按交易日严格一对一对齐；趋势使用 adjusted，价格与涨跌停判断使用 raw。qfq 非历史 point-in-time 复权快照，并在 metadata 中声明。

## Limit Price Resolution

优先 provider 报告值；仅在证券元数据、板块、日期、规则来源和 tick 等证据充分时计算；否则返回 UNKNOWN/`LIMIT_PRICE_UNRELIABLE`，不伪造统一 10%。

## Benchmark Data

benchmark 不按股票市场切换；缺失时相关大盘规则降级，个股规则尽可能继续执行。

## Weekly / Monthly Data

周/月由日线聚合，仅完整周期进入确认规则；当前未收盘周期不会伪装为完整。

## Newly Implemented Rules

交接与 registry 证据为 35 条 implemented、13 条 not implemented；新增边界覆盖 D2、F1-X、F2、R3、R5 等执行器/守卫。

## Single Stock Analysis

Service 返回 canonical symbol、evaluation date、benchmark、raw price、indicators、coverage、规则明细、warnings、provenance 与 R7 forward confirmation。

## FastAPI

已验证 `/api/health`、`/api/rules`、`/api/analyze/{symbol}`、`/api/data/status/{symbol}`；health 不主动探测网络行情。

## CLI

已修复文本输出，现展示 Coverage、Top Positive Rules、Top Risk Rules、Unknown Rules；JSON 使用 `allow_nan=False`。CLI 离线测试已通过。

## Real Data Smoke Test

执行 `<PYTHON_ROOT>/python.exe tools/stage2_smoke.py`，显式使用项目根目录与 `.deps`。600519、000001 的 raw/qfq 和 000001.SH 指数请求均为 ProxyError/`NETWORK_FAILED`。5 个历史日 M5/M30/M60 与 qfq 抽查未执行。标准机器报告：`outputs/smoke/stage2_smoke_report.json`。

## Data Quality

非法核心 OHLC 拒绝；可选字段缺失导致相关规则降级；字段状态、warnings 和 error code 保留在结果中。

## Look-ahead Protection

先按 `date <= as_of` 截断，再计算指标、峰谷、形态和周期；R7 使用持久化冻结快照，历史确认不回写历史评分。

## Tests

最终全量：**374 tests collected；373 passed、1 skipped、0 failed、1 warning**。JUnit：`outputs/runtime/qa-junit.xml`。跳过项为明确排除 Stage2 的自动选股排名 T20。

## Rules Implemented

当前 registry/交接证据为 35 条 implemented；详细清单见 `docs/RULE_IMPLEMENTATION_MATRIX.md` 与 `/api/rules`。

## Rules Not Implemented

13 条：S1–S7、B1、B2、E4、E5、R6、R10。它们不会被报告为已实现业务规则。

## Remaining UNKNOWN Causes

网络/Provider 不可用、核心数据不足、可选字段缺失、历史长度不足、benchmark/limit 不可靠、未完成周月周期、R7 未来确认期未结束，以及上述 13 条未实现规则。

## Files Updated

`app/cli.py`、`tests/test_stage2_service.py`、`docs/DATA_CONTRACT.md`、`docs/STAGE2_DATA_SMOKE_REPORT.md`、`docs/STAGE2_IMPLEMENTATION.md`、`docs/RULE_IMPLEMENTATION_MATRIX.md`、`docs/TEST_REPORT.md`、`README.md`、`.env.example`、`outputs/smoke/stage2_smoke_report.json`、`outputs/runtime/qa-junit.xml`、`outputs/runtime/v14-word-structure.json`、`MEMORY.md`、`.workbuddy/memory/2026-09-26.md`。

## Issues

1. 真实 AKShare 请求受当前代理环境 ProxyError 影响，不能完成真实行情、raw/qfq 对齐和 5 日 M5/M30/M60 抽查。
2. Starlette TestClient 发出 httpx 兼容性弃用 warning，不影响通过。
3. 文档中的部分历史章节仍需继续审阅；本轮已同步核心数量、版本和 Stage2 网络状态。

## Status

**PARTIAL**

网络 smoke 未成功，按用户要求不能标记 PASS；离线质量门禁通过，真实网络证据完整保留。
